---
paths:
  - "backend/src/main/resources/db/**"
  - "backend/src/main/java/**"
  - "backend/**/repository/**"
---

# Database Rules

## Flyway

- All schema changes must use Flyway migrations.
- Never modify the database schema manually as part of normal development.
- Never use Hibernate `ddl-auto=create`, `update`, or `create-drop`.
- Prefer `validate`.

## Migrations

- Migrations are forward-only.
- Never rewrite an already-applied migration.
- Use descriptive migration names.
- Every schema change must be reproducible from a clean database.

## Integrity

Use database constraints where they protect important invariants:
- unique business identifiers
- foreign keys
- non-negative monetary values where appropriate
- required relationships
- uniqueness of contract installment periods
- idempotency uniqueness

Do not rely solely on application validation for concurrency-sensitive uniqueness.

## Auditability

Do not introduce destructive UPDATE/DELETE behavior for posted financial history.

## Repositories

- A module should access its own persistence model.
- Do not query another module's tables directly.
- Cross-module reads must go through an explicit interface or read model.