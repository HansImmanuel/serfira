# Coding Standards

## 1. General Principles

* Prefer clear, explicit, maintainable code over clever or overly abstract solutions.
* Follow existing project conventions before introducing new patterns.
* Keep changes focused on the requested task.
* Avoid unrelated refactors.
* Prefer small, cohesive classes and methods.
* Each method should have one clear responsibility.
* Prefer composition over inheritance.
* Avoid premature abstraction.
* Do not create abstractions until there is a real reuse or boundary that justifies them.
* Use domain terminology consistently with `/docs/03_DOMAIN_MODEL.md`.
* Do not invent alternate names for established domain concepts without a clear reason.

## 2. Naming

* Use descriptive names that communicate intent.
* Avoid unnecessary abbreviations.
* Use standard Java naming conventions:

  * Classes/interfaces/enums: `PascalCase`
  * Methods/variables: `camelCase`
  * Constants: `UPPER_SNAKE_CASE`
  * Packages: lowercase
* Boolean names should read naturally, for example:

  * `isActive`
  * `hasOutstanding`
  * `canSettle`
* Avoid generic names such as:

  * `data`
  * `info`
  * `value`
  * `result`
  * `handler`

  unless their meaning is genuinely obvious from context.

## 3. Java

* Target Java 21.
* Prefer immutable data structures where practical.
* Use `final` fields by default.
* Prefer `record` for immutable DTOs and simple value-like structures when appropriate.
* Use `enum` for finite domain states.
* Prefer explicit types over unnecessary generic abstractions.
* Avoid raw types.
* Avoid unchecked casts unless there is no reasonable alternative and the assumption is documented.
* Prefer standard JDK functionality over introducing a dependency for trivial functionality.

## 4. Nullability

* Avoid `null` when a meaningful alternative exists.
* Use `Optional` primarily for method return values where absence is expected.
* Do not use `Optional` as entity fields.
* Do not use `Optional` as method parameters.
* Do not use `null` as a hidden signal with undocumented meaning.
* Validate required values at the appropriate boundary.

## 5. Methods and Classes

* Keep methods focused and readable.
* Prefer early validation and guard clauses over deeply nested conditionals.
* Avoid methods with excessive branching or unrelated responsibilities.
* Keep classes cohesive.
* Do not create a class solely to satisfy a pattern.
* Do not create utility classes when a domain-specific object or service would communicate intent better.
* Extract logic when extraction improves readability, testability, or reuse.
* Do not extract trivial one-line methods solely to reduce apparent method length.

## 6. Control Flow

* Prefer straightforward control flow.
* Avoid deeply nested `if` statements.
* Prefer guard clauses for invalid or exceptional cases.
* Use `switch` or polymorphism when it makes a finite set of domain states clearer.
* Do not use clever one-liners when a normal block is easier to understand.
* Avoid unnecessary streams when a simple loop is clearer.
* Do not build long or deeply chained stream expressions that are difficult to debug.

## 7. Collections

* Do not expose mutable internal collections directly.
* Prefer immutable or unmodifiable collections where appropriate.
* Do not modify collections unexpectedly as a side effect of a method.
* Use collection types according to intent:

  * `List` for ordered collections
  * `Set` for uniqueness
  * `Map` for key-based lookup
* Do not rely on iteration order unless the collection type guarantees it.
* Avoid unnecessary intermediate collections.

## 8. BigDecimal and Financial Values

* Never use `float` or `double` for monetary or financial calculations.
* Use `BigDecimal` for money and rate calculations.
* Always make scale and rounding behavior explicit where financial calculations are performed.
* Do not introduce ad-hoc rounding in arbitrary parts of a calculation.
* Follow the financial calculation rules defined in `/docs/02_TECH_SPEC.md` and `/docs/03_DOMAIN_MODEL.md`.
* Monetary logic must remain deterministic and testable.

## 9. Spring Boot

* Use constructor injection.
* Do not use field injection.
* Controllers handle HTTP concerns only.
* Application services orchestrate use cases.
* Domain logic must not be hidden inside controllers.
* Repositories should remain persistence-focused.
* Do not place business decisions inside repository implementations.
* Put transaction boundaries at application-service/use-case boundaries.
* Do not annotate large portions of the application with `@Transactional` without understanding the transaction boundary.
* Prefer explicit transaction boundaries for financial operations.

## 10. Time

* Use the project's injectable `Clock`.
* Do not call `LocalDate.now()`, `LocalDateTime.now()`, or `Instant.now()` directly inside business logic.
* Time-dependent business logic must be deterministic under tests.
* Follow the project's documented timezone and date conventions.

## 11. DTOs and Persistence Models

* Do not expose JPA entities directly through API responses.
* Use dedicated request/response DTOs.
* Keep persistence concerns separate from API contracts.
* Do not allow API DTO design to dictate the database model without a deliberate decision.
* Map between API DTOs and domain/persistence models explicitly where necessary.

## 12. Validation

* Validate external input at the API boundary.
* Validate important business invariants again in the appropriate domain/application layer.
* Do not rely solely on frontend validation.
* Do not rely solely on database constraints for business behavior.
* Error messages should explain the invalid condition without exposing sensitive implementation details.

## 13. Exception Handling

* Do not catch exceptions unless the code can meaningfully handle, translate, or recover from them.
* Do not use exceptions for ordinary control flow.
* Preserve the original cause when wrapping an exception.
* Use domain/module-specific exception types where appropriate.
* Do not swallow exceptions silently.
* Do not return generic success responses after an operation actually failed.
* API exceptions must be translated through the project's standard error-handling mechanism.

## 14. Logging

* Use the project's structured logging mechanism.
* Do not use `System.out.println`.
* Logs should provide useful operational context.
* Include correlation/request IDs when available.
* Never log:

  * passwords
  * access tokens
  * refresh tokens
  * secrets
  * full NIK
  * sensitive customer information
* Do not log entire financial request/response payloads by default.
* Prefer logging identifiers and safe metadata instead of sensitive values.

## 15. Comments

* Prefer self-explanatory code over excessive comments.
* Comments should explain why something is done, not simply restate what the code already says.
* Document non-obvious business rules and technical constraints when they cannot be made clear through code alone.
* Do not leave misleading or stale comments.
* Remove comments that become incorrect after refactoring.
* Avoid large block comments that duplicate documentation already present in `/docs`.

## 16. API Design

* Follow `/api/v1/...` conventions.
* Use the project's standard `{data, error}` response envelope.
* Use typed error codes.
* Keep request and response DTOs explicit.
* Do not expose internal exceptions or stack traces.
* Preserve API compatibility unless a breaking change is intentional and documented.
* Use correct HTTP semantics.
* Mutation endpoints must respect the project's idempotency requirements.

## 17. Repository and Persistence Code

* Repository code should focus on persistence and querying.
* Do not place financial business rules in repository methods.
* Keep query intent explicit.
* Use database constraints for important integrity guarantees.
* Do not bypass Flyway or modify schema manually.
* Do not use persistence shortcuts that silently bypass domain invariants.

## 18. Dependency Management

* Prefer the JDK or existing project dependencies when they already solve the problem.
* Do not add a dependency for trivial functionality.
* Every new dependency must have a clear technical justification.
* Avoid adding frameworks or libraries solely because they are popular.
* Do not introduce infrastructure that is not required by the current project phase.

## 19. Refactoring

* Do not refactor unrelated code while implementing a feature.
* Refactor when necessary for correctness, maintainability, or testability.
* Keep behavioral changes and structural refactors distinguishable where practical.
* Preserve existing behavior during purely structural refactoring.
* Do not rename or reorganize broad portions of the codebase without a concrete reason.
* Before removing an abstraction, verify that no other module depends on it.

## 20. Testing Expectations

* New business logic must have corresponding tests.
* Prefer unit tests for pure business logic.
* Use integration tests for database and transaction behavior.
* Use API tests for externally observable HTTP behavior.
* Tests should verify behavior and invariants rather than implementation details.
* Do not weaken or remove tests merely to make the build pass.
* Do not change expected values in golden tests without verifying that the business specification intentionally changed.
* Financial logic should include relevant edge cases.

## 21. Code Quality

Before considering implementation complete, check:

* Is the code understandable without excessive comments?
* Are names precise?
* Is business logic in the correct layer?
* Are module boundaries preserved?
* Are transaction boundaries correct?
* Are financial values represented safely?
* Are exceptions handled correctly?
* Is sensitive data excluded from logs?
* Are tests present for important behavior?
* Did the change avoid unrelated refactoring?
* Does the implementation follow the project documentation?

## 22. Forbidden Practices

Do not:

* use `float` or `double` for financial calculations
* use field injection
* expose JPA entities directly as API contracts
* put business logic in controllers
* bypass module boundaries
* modify posted financial history to hide an error
* swallow exceptions
* use `System.out.println` for application logging
* hardcode secrets
* disable tests to achieve a green build
* suppress warnings without understanding the underlying issue
* introduce unnecessary design patterns
* introduce unnecessary dependencies
* perform unrelated large-scale refactoring

When a shortcut conflicts with correctness, maintainability, security, or a documented Serfira business rule, prefer the documented and explicit solution.
