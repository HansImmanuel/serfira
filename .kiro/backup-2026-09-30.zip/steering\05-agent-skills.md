# Agent Skill Routing

## Purpose

Serfira uses the `rmyndharis/antigravity-skills` skill library as a source of specialized engineering guidance.

Use the most relevant skill for the current task instead of applying generic advice blindly.

## Authority

The following order of authority applies:

1. Serfira project documentation in `/docs`
2. Serfira-specific Cline rules in `.clinerules/`
3. Existing Serfira implementation and established patterns
4. Relevant external skill guidance

Project-specific architecture, business rules, invariants, and scope always override generic skill recommendations.

Never introduce a skill recommendation that conflicts with the Serfira PRD, technical specification, domain model, addendum, or sprint scope.

## Core Skills

### `java-pro`

Use proactively for:

* Java 21 development
* Spring Boot implementation
* Spring Data JPA
* Spring Security
* Gradle
* Testcontainers
* JVM-level concerns
* Java testing and implementation best practices

Important:

* Do not adopt microservices, Spring Cloud, Kafka, WebFlux, virtual threads, CQRS, or other advanced patterns solely because this skill suggests them.
* Only introduce such technology when explicitly required by Serfira documentation or the current task.

### `backend-architect`

Use when:

* designing backend architecture
* introducing or changing module boundaries
* designing application services
* designing integration patterns
* changing transaction boundaries
* designing resilience or observability mechanisms
* reviewing significant backend changes

Preserve Serfira's modular-monolith architecture.

### `api-design-principles`

Use when:

* designing a new API endpoint
* changing an existing API contract
* reviewing REST semantics
* designing pagination/filtering/sorting
* defining errors
* defining authentication/authorization behavior

API decisions must remain consistent with `/docs/02_TECH_SPEC.md`.

### `api-documenter`

Use when:

* adding or changing API endpoints
* updating OpenAPI/Swagger documentation
* documenting request/response schemas
* adding API examples

OpenAPI documentation must remain synchronized with the actual API contract.

### `postgresql`

Use when:

* designing database schema
* adding constraints
* choosing PostgreSQL data types
* designing indexes
* analyzing query paths
* reviewing PostgreSQL-specific behavior

Serfira-specific schema decisions in `/docs/03_DOMAIN_MODEL.md` take precedence over generic PostgreSQL recommendations.

### `database-migrations-sql-migrations`

Use for:

* every Flyway migration
* schema evolution
* migration safety review
* data migration
* migration validation

Never bypass Flyway.

Never rewrite an already-applied migration.

Every schema change must be reproducible from a clean database.

### `architecture-decision-records`

Use when:

* introducing a significant architectural pattern
* changing technology choices
* changing module boundaries
* changing persistence strategy
* making a decision with meaningful trade-offs

Record:

* context
* decision
* considered alternatives
* consequences
* risks

Do not create ADRs for trivial implementation details.

### `security-scanning-security-sast`

Use when:

* modifying authentication or authorization
* handling PII
* changing payment or financial mutation endpoints
* adding external input processing
* modifying database queries
* preparing a milestone or release
* performing security-focused code review

Prioritize:

* injection
* XSS
* IDOR
* CSRF
* hardcoded secrets
* insecure authentication
* insecure authorization
* unsafe deserialization
* sensitive-data exposure

Do not automatically enable or apply destructive auto-fixes without review.

### `tdd-orchestrator`

Use when:

* implementing a new business feature
* implementing a new domain rule
* modifying important financial behavior
* implementing acceptance-driven workflows

Prefer:

1. define expected behavior
2. write focused tests
3. implement
4. run targeted tests
5. run the broader test suite

Financial invariants and golden tests must be treated as first-class acceptance criteria.

## Review Skills

### `architect-review`

Use before:

* major architectural changes
* new infrastructure
* changing module boundaries
* introducing a new architectural pattern
* resolving architectural ambiguity

### `code-review-excellence`

Use before:

* declaring a significant feature complete
* preparing a pull request
* reviewing a large refactor
* reviewing financial or security-sensitive changes

Review for:

* correctness
* architecture
* test coverage
* maintainability
* security
* regression risk
* scope creep

### `api-testing-observability-api-mock`

Use when:

* adding API integration tests
* designing API contract tests
* testing external API boundaries
* mocking external services
* validating request/response contracts

## Frontend Skills

Do not use frontend skills until the frontend exists.

### `frontend-developer`

Use for:

* Next.js implementation
* React components
* TypeScript frontend architecture
* client/server component decisions
* frontend accessibility
* frontend performance

### `nextjs-app-router-patterns`

Use for:

* App Router architecture
* Server Components
* Client Components
* streaming
* route organization
* data fetching
* loading/error boundaries

Frontend must remain a client of the Spring Boot API.

Business rules and financial calculations belong in the backend.

## Skill Selection Rules

* Prefer one primary skill and only the supporting skills required by the task.
* Do not invoke every skill for every task.
* Do not use a skill merely because its topic appears somewhere in the repository.
* Do not introduce technology solely because a skill recommends it.
* When multiple skills apply, prioritize:

  1. domain correctness
  2. architecture
  3. implementation
  4. testing
  5. security/review
  6. documentation

## Example Skill Routing

### New payment endpoint

Use:

* `backend-architect`
* `api-design-principles`
* `java-pro`
* `tdd-orchestrator`
* `security-scanning-security-sast`
* `api-documenter`

### New Flyway migration

Use:

* `postgresql`
* `database-migrations-sql-migrations`
* `java-pro` only if Java persistence code also changes

### New schedule calculation

Use:

* `java-pro`
* `tdd-orchestrator`

Prioritize Serfira's financial rules and golden tests.

### Major architecture change

Use:

* `backend-architect`
* `architect-review`
* `architecture-decision-records`

### New Next.js page

Use:

* `frontend-developer`
* `nextjs-app-router-patterns`

Add `api-design-principles` only if the backend API contract also changes.

## Context7

Use Context7 when:
- library/framework behavior may depend on the current version
- implementing Spring Boot, Spring Security, Spring Data JPA, Flyway, Gradle, Next.js, React, or TypeScript features
- official/current documentation is preferable to model memory

Prefer Context7 documentation over remembered framework behavior.

Do not use Context7 to override Serfira-specific business rules or architecture.

## Final Rule

Skills are advisors, not authorities.

The agent must never replace Serfira's documented requirements with a generic pattern from a skill.

When skill guidance and project documentation conflict, follow the project documentation and explicitly note the conflict.
