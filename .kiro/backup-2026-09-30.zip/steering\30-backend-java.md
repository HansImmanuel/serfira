---
paths:
  - "backend/**/*.java"
  - "backend/build.gradle"
  - "backend/build.gradle.kts"
---

# Java and Spring Rules

## Java

- Java 21.
- Use constructor injection.
- Prefer immutable values where practical.
- Prefer `final` fields.
- Use `BigDecimal` for money.
- Avoid unnecessary inheritance.
- Prefer composition over inheritance.

## Spring

- Controllers handle HTTP concerns only.
- Application services orchestrate use cases.
- Domain logic belongs in domain/application layers, not controllers.
- Put `@Transactional` at application-service boundaries.
- Use the shared injectable `Clock`.
- Do not call `LocalDate.now()` or `Instant.now()` directly inside business logic.

## Validation

- Validate API input at the boundary.
- Validate business invariants again inside the appropriate domain/application layer.
- Do not rely only on database constraints for business correctness.

## Error Handling

- Use the project's standard error envelope.
- Use typed/module-specific error codes.
- Do not expose stack traces or internal implementation details in API responses.

## Naming

- Classes: `PascalCase`
- Methods/variables: `camelCase`
- Constants: `UPPER_SNAKE_CASE`
- Use domain terminology from the project docs.
- Do not introduce synonyms for established domain concepts without reason.