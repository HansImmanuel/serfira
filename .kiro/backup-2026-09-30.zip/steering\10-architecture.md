---
paths:
  - "backend/**"
---

# Backend Architecture

## Architecture

Serfira backend is a modular monolith.

Modules:
- `contract`
- `payment`
- `penalty`
- `settlement`
- `ledger`
- `reporting`
- `shared`

Each module owns its own domain logic.

## Package Structure

Prefer:

`com.serfira.<module>.api`
`com.serfira.<module>.application`
`com.serfira.<module>.domain`
`com.serfira.<module>.infrastructure`

Do not organize the entire application into global `controller`, `service`, `repository`, and `entity` packages.

## Module Boundaries

- Modules must not directly query another module's repositories or tables.
- Cross-module behavior must go through an application-service interface or explicit module contract.
- `ledger` must remain independent from business modules.
- `reporting` is read-only.
- Controllers must not contain business logic.
- Transaction boundaries belong in application services.

## Dependency Direction

Prefer:

`api → application → domain`

Infrastructure implements ports/interfaces rather than becoming the owner of business rules.

## Architectural Discipline

- Do not introduce microservices.
- Do not introduce Kafka for ordinary feature work.
- Do not bypass module boundaries for convenience.
- If a requested feature appears to violate the architecture, explain the conflict before implementing it.