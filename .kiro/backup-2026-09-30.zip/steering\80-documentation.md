---
paths:
  - "docs/**"
  - "README.md"
  - "AGENTS.md"
  - ".clinerules/**"
---

# Documentation Rules

## Source of Truth

Keep these responsibilities separate:

- PRD → what the system must do
- Technical spec → how the system is structured
- Domain model → entities, invariants, and business semantics
- Addendum → resolved gaps and explicit decisions
- Sprint plan → implementation order and scope
- Cline rules → how the coding agent must work

Do not duplicate entire specifications inside agent rules.

## Consistency

When changing a business rule or architecture:
- update the authoritative document
- update affected derived documentation
- update relevant sprint references when scope changes

## Writing

- Prefer precise terminology.
- Avoid ambiguous terms such as "balance" or "outstanding" when a more specific term exists.
- Include examples for calculations or tricky business rules.
- Record important architectural decisions as ADRs when appropriate.

## Agent Rule Maintenance

Keep `.clinerules` concise.
Remove obsolete rules instead of accumulating historical instructions.